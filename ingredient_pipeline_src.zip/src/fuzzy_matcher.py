
from rapidfuzz import process, fuzz
import pandas as pd
from src.ingredient_db import load_ingredient_db, get_known_terms

db = load_ingredient_db()
known_terms = get_known_terms(db)

def match_ingredient(ingredient, threshold=80):
    """Fuzzy match corrected ingredient to database."""
    cleaned = ingredient.lower().strip()
    match, score, _ = process.extractOne(cleaned, known_terms, scorer=fuzz.token_sort_ratio)
    if score >= threshold:
        db_row = db[db['Name'].str.lower() == match].iloc[0]
        return {
            "Input": ingredient,
            "Matched Name": db_row['Name'],
            "Description": db_row['Description'],
            "Rating": db_row['Rating'],
            "Score": score
        }
    else:
        return {
            "Input": ingredient,
            "Matched Name": None,
            "Description": None,
            "Rating": None,
            "Score": score
        }
