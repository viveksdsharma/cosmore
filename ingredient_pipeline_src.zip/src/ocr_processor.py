
import pytesseract
from PIL import Image
import pandas as pd
from src.fuzzy_matcher import match_ingredient

def extract_ingredients_from_image(image_path):
    """Extract text lines from label image."""
    img = Image.open(image_path)
    ocr_text = pytesseract.image_to_string(img)
    lines = [line for line in ocr_text.split('\n') if line.strip()]
    return lines

def process_image(image_path, threshold=80):
    """Full OCR -> matching pipeline."""
    lines = extract_ingredients_from_image(image_path)
    results = [match_ingredient(line, threshold) for line in lines]
    df_results = pd.DataFrame(results)
    unmatched = df_results[df_results['Matched Name'].isna()]
    if not unmatched.empty:
        unmatched.to_csv('unmatched_ingredients.csv', mode='a', index=False, header=False)
    return df_results
