
import pandas as pd
from rapidfuzz import process, fuzz
from .ingredient_db import load_ingredient_db, get_known_terms

db = load_ingredient_db()
known_terms = get_known_terms(db)

def auto_correct_ocr(ocr_text, threshold=80):
    match = process.extractOne(ocr_text.lower().strip(), known_terms, scorer=fuzz.token_sort_ratio)
    if match and match[1] >= threshold:
        return match[0]
    return ocr_text.lower().strip()

def match_ingredient(ingredient, threshold=80):
    corrected = auto_correct_ocr(ingredient, threshold)
    match = process.extractOne(corrected, db['Name'], scorer=fuzz.token_sort_ratio)
    if match and match[1] >= threshold:
        row = db[db['Name'] == match[0]].iloc[0]
        return {
            'Input': ingredient,
            'Corrected': corrected,
            'Matched Name': row['Name'],
            'Description': row['Description'],
            'Rating': row['Rating'],
            'Score': match[1]
        }
    return {
        'Input': ingredient,
        'Corrected': corrected,
        'Matched Name': None,
        'Description': None,
        'Rating': None,
        'Score': match[1] if match else 0
    }

def bulk_process(ingredient_list, threshold=80, unmatched_log='unmatched_ingredients.csv'):
    results = []
    unmatched = []
    for ing in ingredient_list:
        res = match_ingredient(ing, threshold)
        results.append(res)
        if res['Matched Name'] is None:
            unmatched.append(res)
    if unmatched:
        pd.DataFrame(unmatched).to_csv(unmatched_log, mode='a', index=False, header=False)
        print(f"⚠️ Logged {len(unmatched)} unmatched ingredients to '{unmatched_log}'")
    return pd.DataFrame(results)
